//
//  ResponseEntity+CoreDataProperties.swift
//  MechineTest
//
//  Created by Mc on 08/03/24.
//
//

//import Foundation
//import CoreData
//
//
//extension ResponseEntity {
//
//    @nonobjc public class func fetchRequest() -> NSFetchRequest<ResponseEntity> {
//        return NSFetchRequest<ResponseEntity>(entityName: "ResponseEntity")
//    }
//
//    @NSManaged public var product_image: String?
//
//}
//
//extension ResponseEntity : Identifiable {
//
//}
