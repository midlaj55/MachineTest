//
//  Product.swift
//  MechineTest
//
//  Created by Mc on 08/03/24.
//

import CoreData

public class Product: NSManagedObject {
    @NSManaged public var productName: String
    @NSManaged public var imageData: Data?
}
