//
//  MechineTestApp.swift
//  MechineTest
//
//  Created by Mc on 08/03/24.
//

import SwiftUI

@main
struct MechineTestApp: App {
//    let persistenceController = PersistenceController.shared

    var body: some Scene {
        WindowGroup {
            ContentView()
//                .environment(\.managedObjectContext, persistenceController.container.viewContext)
        }
    }
}
