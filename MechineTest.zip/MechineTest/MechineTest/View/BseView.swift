//
//  ContentView.swift
//  MechineTest
//
//  Created by Mc on 08/03/24.
//

import SwiftUI
//import CoreData

public enum ListType: String {
    case banner_single
    case productsMostPopuplar
    case bestProduct
    case banner_slider
    case catagories
}

struct BseView: View {
    @StateObject var viewModel = ProductViewModel()
//    @Environment(\.managedObjectContext) private var viewContext

    var body: some View {
        VStack {
            SearchBarView()
            ScrollView {
                VStack {
                    SliderView()
                    TitleView(itemType: .bestProduct)
                    ItemListView(itemType: .productsMostPopuplar)
                    CardView()
                    TitleView(itemType: .catagories)
                    CatagoriesListView()
                    TitleView(itemType: .productsMostPopuplar)
                    ItemListView(itemType: .bestProduct)
                    
                }
                .padding(EdgeInsets(top: 0, leading: 8, bottom: 0, trailing: 8))
            }
        }
        .environmentObject(viewModel)
        .onAppear {
            viewModel.getItemListValues()
        }
    }
}

struct BseView_Previews: PreviewProvider {
    static var previews: some View {
        BseView()
    }
}

//extension BseView {
//    func saveResponseToCoreData(apiResponse: ContentItem) {
//        withAnimation {
//            let newResponse = ResponseEntity(context: viewContext)
//            newResponse.product_image = apiResponse.product_image
//            
//            do {
//                try viewContext.save()
//            } catch {
//                let nsError = error as NSError
//                fatalError("Unresolved error \(nsError), \(nsError.userInfo)")
//            }
//        }
//    }
//}
