//
//  CatagoriesListView.swift
//  MechineTest
//
//  Created by Mc on 08/03/24.
//

import SwiftUI
import Kingfisher

struct CatagoriesListView: View {
    @EnvironmentObject var viewModel: ProductViewModel

    var body: some View {
        HStack(spacing: 16) {
            ForEach(viewModel.categoriIteam, id: \.self) { index in
                CatagoriesItemView(data: index)
                    .frame(width: 74, height: 64)
            }
        }
    }
}

struct CatagoriesItemView: View {
    @State var data: ContentItem?

    var body: some View {
        VStack {
            KFImage(URL(string: data?.imageUrl ?? ""))
                .resizable()
                .scaledToFit()
                .cornerRadius(10)
                .clipped()
            Text(data?.title ?? "")
                .font(.system(size: 6))
        }
        .overlay(
            RoundedRectangle(cornerRadius: 10)
                .stroke(Color.gray, lineWidth: 1)
        )
        .frame(width: 74, height: 64)
    }
}

struct CatagoriesListView_Previews: PreviewProvider {
    static var previews: some View {
        CatagoriesListView()
            .environmentObject(ProductViewModel())
    }
}
