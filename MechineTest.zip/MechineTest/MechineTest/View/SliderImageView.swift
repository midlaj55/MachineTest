//
//  SliderImageView.swift
//  MechineTest
//
//  Created by Mc on 08/03/24.
//

import SwiftUI
import Kingfisher

struct SliderView: View {
    @EnvironmentObject var viewModel: ProductViewModel

    var body: some View {
        VStack {
            TabView {
                ForEach(viewModel.sliderIteam, id: \.self) { item in
                    SliderImageView(data: item)
                }
            }
            .tabViewStyle(PageTabViewStyle(indexDisplayMode: .automatic))
            .frame(height: 104)
        }
    }
}

struct SliderImageView: View {
    @State var data: ContentItem?

    var body: some View{
        KFImage(URL(string: data?.imageUrl ?? "SliderImage"))
            .resizable()
            .scaledToFill()
    }
}
