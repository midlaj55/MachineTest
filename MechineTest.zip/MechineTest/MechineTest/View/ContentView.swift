//
//  ContentView1.swift
//  MechineTest
//
//  Created by Mc on 08/03/24.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        TabBarView()
    }
}

#Preview {
    ContentView()
}
